function showPage(page){
  let content = document.getElementById("content");

  if(page === "verbs"){
    content.innerHTML = `
      <h2>Verb School</h2>
      <ul>
        <li>Qal = simple action</li>
        <li>Piel = intensive</li>
        <li>Hiphil = cause action</li>
        <li>Niphal = passive</li>
      </ul>
    `;
  }

  if(page === "lexicon"){
    let words = DATA.lexicon.map(w => `
      <div>
        <h3>${w.hebrew}</h3>
        <p>${w.phonetic}</p>
        <p>${w.gloss}</p>
      </div>
    `).join("");

    content.innerHTML = "<h2>Lexicon</h2>" + words;
  }

  if(page === "parsing"){
    content.innerHTML = `
      <h2>Parsing</h2>
      <p>Stem + Form + Person + Meaning</p>
      <p>שמר = Qal perfect 3ms</p>
    `;
  }
}
