const DATA = {
lexicon: [
{hebrew:"שמר", phonetic:"Sha-mar", gloss:"to guard"},
{hebrew:"הלך", phonetic:"Ha-lakh", gloss:"to walk"},
{hebrew:"נתן", phonetic:"Na-tan", gloss:"to give"},
{hebrew:"רוח", phonetic:"Roo-akh", gloss:"spirit"},
{hebrew:"שלום", phonetic:"Sha-lom", gloss:"peace"}
]
}
